﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MusicAlbum.Data.Service.Abstract
{
   public interface IArtistMasterService
    {
        ArtistMaster AddArtist(ArtistMaster artistMaster);
        List<ArtistMaster> GetAllArtists();
        ArtistMaster GetArtistById(int titleid);
        ArtistMaster UpdateArtist(ArtistMaster artistMaster);
        ArtistMaster DeleteArtist(ArtistMaster artistMaster);
    }
}
