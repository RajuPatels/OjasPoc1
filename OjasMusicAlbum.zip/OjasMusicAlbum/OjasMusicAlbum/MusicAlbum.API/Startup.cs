using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MusicAlbum.API.Business.Abstract;
using MusicAlbum.API.Business.Derive;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using MusicAlbum.Data.Service.Derive;

namespace MusicAlbum.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddDbContext<music_albumdbContext>(options => options.UseMySQL("Server=127.0.0.1;port=3306;Database=ojaspoc1;Uid=root;Pwd=Try@1996@"));        
            services.AddTransient<IAlbumsContext, AlbumsContext>();
            services.AddTransient<IAlbumsService, AlbumsService>();
            services.AddTransient<ITitleMasterContext, TitleMasterContext>();
            services.AddTransient<ITitleMasterService, TitleMasterService>();
            services.AddTransient<IArtistMasterContext, ArtistMasterContext>();
            services.AddTransient<IArtistMasterService, ArtistMasterService>();
            services.AddTransient<IGenreMasterContext, GenreMasterContext>();
            services.AddTransient<IGenreMasterService, GenreMasterService>();
            services.AddTransient<IMusicMasterContext, MusicMasterContext>();
            services.AddTransient<IMusicMasterService, MusicMasterService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
