﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Abstract
{
   public interface ITitleMasterContext
    {
        TitleMaster AddTitle(TitleMaster titleMaster);
        List<string> GetAllTitles();
        List<TitleMaster> GetTitleById(int albumid);
        TitleMaster UpdateTitle(TitleMaster titleMaster);
        TitleMaster DeleteTitle(TitleMaster titleMaster);
    }
}
