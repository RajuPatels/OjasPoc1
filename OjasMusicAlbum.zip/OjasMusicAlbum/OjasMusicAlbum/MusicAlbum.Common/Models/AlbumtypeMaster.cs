﻿using System;
using System.Collections.Generic;

namespace MusicAlbum.Common.Models
{
    public partial class AlbumtypeMaster
    {
        public AlbumtypeMaster()
        {
            MusicMaster = new HashSet<MusicMaster>();
            TitleMaster = new HashSet<TitleMaster>();
        }

        public int AlbumId { get; set; }
        public string AlbumName { get; set; }
        public int? Year { get; set; }
        public int? GenreId { get; set; }

        public virtual GenreMaster Genre { get; set; }
        public virtual ICollection<MusicMaster> MusicMaster { get; set; }
        public virtual ICollection<TitleMaster> TitleMaster { get; set; }
    }
}
