﻿using System;
using System.Collections.Generic;

namespace MusicAlbum.Common.Models
{
    public partial class ArtistMaster
    {
        public ArtistMaster()
        {
            MusicMaster = new HashSet<MusicMaster>();
        }

        public int ArtistId { get; set; }
        public string ArtistName { get; set; }
        public string Profession { get; set; }
        public int? TitleId { get; set; }
        public string MusicdirectorName { get; set; }

        public virtual TitleMaster Title { get; set; }
        public virtual ICollection<MusicMaster> MusicMaster { get; set; }
    }
}
