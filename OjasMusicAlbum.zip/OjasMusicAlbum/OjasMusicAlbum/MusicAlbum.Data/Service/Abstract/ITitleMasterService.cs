﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MusicAlbum.Data.Service.Abstract
{
   public interface ITitleMasterService
    {
        TitleMaster AddTitle (TitleMaster titleMaster);
        List<string> GetAllTitles();
        List<TitleMaster> GetTitleById(int albumid);
        TitleMaster UpdateTitle(TitleMaster titleMaster);
        TitleMaster DeleteTitle(TitleMaster titleMaster);
    }
}
