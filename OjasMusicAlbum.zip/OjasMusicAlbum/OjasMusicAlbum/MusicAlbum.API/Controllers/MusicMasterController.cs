﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;


namespace MusicAlbum.API.Controllers
{
    #region
    [Route("api/[controller]")]
    [ApiController]
    public class MusicMasterController : ControllerBase
    {
        private readonly IMusicMasterContext _musicMasterContext;
        private readonly IConfiguration _configuration;
        public MusicMasterController(IMusicMasterContext musicMasterContext, IConfiguration configuration)
        {
            _musicMasterContext = musicMasterContext;
            _configuration = configuration;
        }

        //reference  IMusicMasterContext
        [HttpPost("AddMusic")]
        public IActionResult AddMusic(MusicMaster musicMaster)
        {
            var resp = _musicMasterContext.AddMusic(musicMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Music added successfully" });
                return response;
            }
            else
            {
                //JsonErrors k = new CustomExceptions(ErrorCodes.error1.ToString(), _configuration).GetErrorObject();
                //return Ok(k);

                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }
        //reference  IMusicMasterContext
        [HttpGet("GetAllMusics")]
        public IActionResult GetAllMusics()
        {
            var result = _musicMasterContext.GetAllMusics();
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }
        }
        //reference  IMusicMasterContext

        [HttpGet("GetMusicById")]
        public IActionResult GetMusicById(MusicMaster musicMaster)
        {
            var result = _musicMasterContext.GetMusicById(musicMaster);
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                //JsonErrors k = new CustomExceptions(ErrorCodes.error1.ToString(), _configuration).GetErrorObject();
                //return Ok(k);
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }

        }
        //reference  IMusicMasterContext

        [HttpPost("GetMusic")]
        public IActionResult GetMusic(MusicDetailsViewModel m)
        {
            var result = _musicMasterContext.GetMusic(m);
            if (result != null)
            {
                var response = Ok(new { Album = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Not found" });
                return response;
            }

        }
        //reference  IMusicMasterContext
        [HttpPost("UpdateMusic")]
        public IActionResult UpdateMusic(MusicMaster musicMaster)
        {
            var resp = _musicMasterContext.UpdateMusic(musicMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Music Updated successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 200, success = true, data = "Music Updated successfully" });
                return response;
               
            }
        }

        //reference  IMusicMasterContext
        [HttpGet("DeleteMusic")]
        public IActionResult DeleteMusic(MusicMaster musicMaster)
        {
            var resp = _musicMasterContext.DeleteMusic(musicMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Music Deleted successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Not found" });
                return response;
            }
        }
    }
    #endregion
}