﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;

namespace MusicAlbum.API.Controllers
{
    #region
    [Route("api/[controller]")]
    [ApiController]
    public class TitleMasterController : ControllerBase
    {
        private readonly ITitleMasterContext _titleMasterContext;
        private readonly IConfiguration _configuration;
        public TitleMasterController(ITitleMasterContext titleMasterContext, IConfiguration configuration)
        {
            _titleMasterContext = titleMasterContext;
            _configuration = configuration;
        }

        //reference ITitleMasterContext 
        [HttpPost("AddTitle")]
        public IActionResult AddTitle(TitleMaster titleMaster)
        {
            var resp = _titleMasterContext.AddTitle(titleMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Title added successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }

        //reference ITitleMasterContext 
        [HttpGet("GetAllTitles")]
        public IActionResult GetAllTitles()
        {
            var result = _titleMasterContext.GetAllTitles();
            if (result != null)
            {
                var response = Ok(new { Songs = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }
        }

        //reference ITitleMasterContext 
        [HttpGet("GetTitleById")]
        public IActionResult GetTitleById(int albumid)
        {
            var result = _titleMasterContext.GetTitleById(albumid);
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }

        }

        //reference ITitleMasterContext 

        [HttpPost("UpdateAlbum")]
        public IActionResult UpdateAlbum(TitleMaster titleMaster)
        {
            var resp = _titleMasterContext.UpdateTitle(titleMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Title Updated successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }

        //reference ITitleMasterContext 
        [HttpGet("DeleteTitle")]
        public IActionResult DeleteTitle(TitleMaster titleMaster)
        {
            var resp = _titleMasterContext.DeleteTitle(titleMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Title Deleted successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Not found" });
                return response;
            }
        }
    }
    #endregion 
}