﻿using Microsoft.EntityFrameworkCore;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MusicAlbum.Data.Service.Derive
{
    public class MusicMasterService : IMusicMasterService
    {
    
        music_albumdbContext _db = new music_albumdbContext();
        public MusicMaster AddMusic(MusicMaster musicMaster)
        {
            try
            {
                _db.MusicMaster.Add(musicMaster);
                _db.SaveChanges();
            }
            catch (DbUpdateException ex)
            {

            }
            return musicMaster;
        }
        public MusicMaster DeleteMusic(MusicMaster musicMaster)
        {
            var data = _db.MusicMaster.Where(x => x.MusicId == musicMaster.MusicId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _db.Entry(data).State = EntityState.Deleted;
                    _db.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public List<MusicMaster> GetAllMusics()
        {
            List<MusicMaster> musicMasters = _db.MusicMaster.ToList();
            return musicMasters;
        }

        public Object GetMusic(MusicDetailsViewModel m)
        {
            var data = from mm in _db.MusicMaster
                       join gm in _db.GenreMaster on mm.GenreId equals gm.GenreId
                       join am in _db.AlbumtypeMaster on mm.AlbumId equals am.AlbumId
                       join tm in _db.TitleMaster on mm.TitleId equals tm.TitleId
                       join arm in _db.ArtistMaster on mm.ArtistId equals arm.ArtistId

                       where gm.GenereName == (m.GenereName == "" ? gm.GenereName : m.GenereName)
                       where am.AlbumName == (m.AlbumName == "" ? am.AlbumName : m.AlbumName)
                       where tm.TitleName == (m.TitleName == "" ? tm.TitleName : m.TitleName)
                       where arm.ArtistName == (m.ArtistName == "" ? arm.ArtistName : m.ArtistName)
                       where arm.MusicdirectorName == (m.MusicdirectorName == "" ? arm.MusicdirectorName : m.MusicdirectorName)
                       select new MusicDetailsViewModel
                       {
                           GenereName = gm.GenereName,
                           AlbumName = am.AlbumName,
                           TitleName = tm.TitleName,
                           ArtistName = arm.ArtistName,
                           MusicdirectorName = arm.MusicdirectorName
                       };

            return data;
        }

        public MusicMaster GetMusicById(MusicMaster musicMaster)
        {
            var data = _db.MusicMaster.Where(x => x.MusicId == musicMaster.MusicId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _db.MusicMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public MusicMaster UpdateMusic(MusicMaster musicMaster)
        {
            MusicMaster data = _db.MusicMaster.Where(x => x.MusicId == musicMaster.MusicId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    data.TitleId = (musicMaster.TitleId == 0) ? data.TitleId : musicMaster.TitleId;
                    data.AlbumId = (musicMaster.AlbumId == 0) ? data.AlbumId : musicMaster.AlbumId;
                    data.ArtistId = (musicMaster.ArtistId == 0) ? data.ArtistId : musicMaster.ArtistId;
                    data.GenreId = (musicMaster.GenreId == 0) ? data.GenreId : musicMaster.GenreId;
                    _db.Entry(data).State = EntityState.Modified;
                    _db.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }
    }
}
