﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MusicAlbum.Data.Service.Abstract
{
   public interface IGenreMasterService
    {
        GenreMaster AddGenre(GenreMaster genreMaster);
        List<GenreMaster> GetAllGenre();
        GenreMaster GetGenreById(GenreMaster genreMaster);
        GenreMaster UpdateGenre(GenreMaster genreMaster);
        GenreMaster DeleteGenre(GenreMaster genreMaster);
    }
}
