﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MusicAlbum.Data.Service.Abstract
{
   public interface IMusicMasterService
    {
        MusicMaster AddMusic(MusicMaster musicMaster);
        List<MusicMaster> GetAllMusics();
        MusicMaster GetMusicById(MusicMaster musicMaster);
        MusicMaster UpdateMusic(MusicMaster musicMaster);
        MusicMaster DeleteMusic(MusicMaster musicMaster);
        Object GetMusic(MusicDetailsViewModel m);
    }
}
