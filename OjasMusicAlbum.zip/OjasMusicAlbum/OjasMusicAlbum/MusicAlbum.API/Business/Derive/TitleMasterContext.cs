﻿using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Derive
{
    public class TitleMasterContext : ITitleMasterContext
    {
        private readonly ITitleMasterService _titleMasterService;
        public TitleMasterContext(ITitleMasterService titleMasterService)
        {
            _titleMasterService = titleMasterService;
        }
        public TitleMaster AddTitle(TitleMaster titleMaster)
        {
            return _titleMasterService.AddTitle(titleMaster);
        }

        public TitleMaster DeleteTitle(TitleMaster titleMaster)
        {
            return _titleMasterService.DeleteTitle(titleMaster);
        }

        public List<string> GetAllTitles()
        {
            return _titleMasterService.GetAllTitles();
        }

        public List<TitleMaster> GetTitleById(int albumid)
        {
            return _titleMasterService.GetTitleById(albumid);
        }

        public TitleMaster UpdateTitle(TitleMaster titleMaster)
        {
            return _titleMasterService.UpdateTitle(titleMaster);
        }
    }
}
