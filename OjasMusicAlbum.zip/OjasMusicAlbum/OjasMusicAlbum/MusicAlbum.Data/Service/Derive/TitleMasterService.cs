﻿using Microsoft.EntityFrameworkCore;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MusicAlbum.Data.Service.Derive
{
    public class TitleMasterService : ITitleMasterService
    {
        music_albumdbContext _music_AlbumdbContext = new music_albumdbContext();

        public TitleMaster AddTitle(TitleMaster titleMaster)
        {
            try
            {
                _music_AlbumdbContext.TitleMaster.Add(titleMaster);
                _music_AlbumdbContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {

            }
            return titleMaster;
        }

        public TitleMaster DeleteTitle(TitleMaster titleMaster)
        {
            var data = _music_AlbumdbContext.TitleMaster.Where(x => x.TitleId == titleMaster.TitleId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.Entry(data).State = EntityState.Deleted;
                    _music_AlbumdbContext.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public List<string> GetAllTitles()
        {
            List<string> titleMaster = _music_AlbumdbContext.TitleMaster.Select(x => x.TitleName).ToList();
            return titleMaster;
        }

        public List<TitleMaster> GetTitleById(int albumid)
        {
            var data = _music_AlbumdbContext.TitleMaster.Where(x => x.AlbumId == albumid).ToList();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.TitleMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public TitleMaster UpdateTitle(TitleMaster titleMaster)
        {
            TitleMaster data = _music_AlbumdbContext.TitleMaster.Where(x => x.TitleId == titleMaster.TitleId).FirstOrDefault();
            try
            {
                if(data!=null)
                {
                    data.TitleName = string.IsNullOrEmpty(titleMaster.TitleName) ? data.TitleName : titleMaster.TitleName;
                    _music_AlbumdbContext.Entry(data).State = EntityState.Modified;
                    _music_AlbumdbContext.SaveChanges();

                }

            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }
    }
}
