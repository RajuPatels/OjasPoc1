﻿using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Derive
{
    public class MusicMasterContext : IMusicMasterContext
    {
        private readonly IMusicMasterService _musicMasterService;
        public MusicMasterContext(IMusicMasterService musicMasterService)
        {
            _musicMasterService = musicMasterService;
        }
        public MusicMaster AddMusic(MusicMaster musicMaster)
        {
            return _musicMasterService.AddMusic(musicMaster);
        }

        public MusicMaster DeleteMusic(MusicMaster musicMaster)
        {
            return _musicMasterService.DeleteMusic(musicMaster);
        }

        public List<MusicMaster> GetAllMusics()
        {
            return _musicMasterService.GetAllMusics();
        }

        public Object GetMusic(MusicDetailsViewModel m)
        {
            return _musicMasterService.GetMusic(m);
        }

        public MusicMaster GetMusicById(MusicMaster musicMaster)
        {
            return _musicMasterService.GetMusicById(musicMaster);
        }

        public MusicMaster UpdateMusic(MusicMaster musicMaster)
        {
            return _musicMasterService.UpdateMusic(musicMaster);
        }
    }
}
