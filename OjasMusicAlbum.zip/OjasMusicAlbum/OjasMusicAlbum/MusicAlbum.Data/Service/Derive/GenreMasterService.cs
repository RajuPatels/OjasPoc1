﻿using Microsoft.EntityFrameworkCore;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MusicAlbum.Data.Service.Derive
{
    public class GenreMasterService : IGenreMasterService
    {
        music_albumdbContext _music_AlbumdbContext = new music_albumdbContext();
        public GenreMasterService(music_albumdbContext music_AlbumdbContext)
        {
            _music_AlbumdbContext = music_AlbumdbContext;
        }
        public GenreMaster AddGenre(GenreMaster genreMaster)
        {
            try
            {
                _music_AlbumdbContext.GenreMaster.Add(genreMaster);
                _music_AlbumdbContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {

            }
            return genreMaster;
        }

        public GenreMaster DeleteGenre(GenreMaster genreMaster)
        {
            var data = _music_AlbumdbContext.GenreMaster.Where(x => x.GenreId == genreMaster.GenreId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.Entry(data).State = EntityState.Deleted;
                    _music_AlbumdbContext.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public List<GenreMaster> GetAllGenre()
        {
            List<GenreMaster> genreMasters = _music_AlbumdbContext.GenreMaster.ToList();
            return genreMasters;
        }

        public GenreMaster GetGenreById(GenreMaster genreMaster)
        {
            var data = _music_AlbumdbContext.GenreMaster.Where(x => x.GenreId == genreMaster.GenreId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.GenreMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public GenreMaster UpdateGenre(GenreMaster genreMaster)
        {
            GenreMaster data = _music_AlbumdbContext.GenreMaster.Where(x => x.GenreId == genreMaster.GenreId).FirstOrDefault();
            try
            {
                if(data!=null)
                {
                    data.GenereName = string.IsNullOrEmpty(genreMaster.GenereName) ? data.GenereName : genreMaster.GenereName;
                    _music_AlbumdbContext.Entry(data).State = EntityState.Modified;
                    _music_AlbumdbContext.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }
    }
}
