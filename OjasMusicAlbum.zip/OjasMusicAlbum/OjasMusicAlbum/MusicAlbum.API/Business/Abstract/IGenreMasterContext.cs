﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Abstract
{
   public interface IGenreMasterContext
    {
        GenreMaster AddGenre(GenreMaster genreMaster);
        List<GenreMaster> GetAllGenre();
        GenreMaster GetGenreById(GenreMaster genreMaster);
        GenreMaster UpdateGenre(GenreMaster genreMaster);
        GenreMaster DeleteGenre(GenreMaster genreMaster);
    }
}
