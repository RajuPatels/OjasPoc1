-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: ojaspoc1
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artist_master`
--

DROP TABLE IF EXISTS `artist_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artist_master` (
  `artist_id` int NOT NULL AUTO_INCREMENT,
  `artist_name` varchar(20) DEFAULT NULL,
  `profession` varchar(20) DEFAULT NULL,
  `title_id` int DEFAULT NULL,
  `musicdirector_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`artist_id`),
  KEY `title_id` (`title_id`),
  CONSTRAINT `artist_master_ibfk_1` FOREIGN KEY (`title_id`) REFERENCES `title_master` (`title_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist_master`
--

LOCK TABLES `artist_master` WRITE;
/*!40000 ALTER TABLE `artist_master` DISABLE KEYS */;
INSERT INTO `artist_master` VALUES (1,'Hemachendra','singer',1,'J.B'),(2,'SravanaBhargavi','Singer',2,'J.B'),(3,'GeethaMadhuri','Singer',3,'J.B'),(4,'Revanth','Lyricist',4,'Thaman'),(5,'Sunitha','singer',5,'Thaman'),(6,'Sunitha','singer',6,'Thaman'),(7,'M.M Keeravani','singer',7,'Chekri'),(8,'Sunitha','singer',8,'Chekri'),(9,'Hemachendra','singer',9,'Chekri'),(10,'Revanth','singer',10,'A.R Rehman'),(11,'VijayPrakash','singer',11,'A.R Rehman'),(12,'Chinmayi','singer',12,'A.R Rehman'),(13,'Karthik','singer',13,'A.R Rehman'),(14,'VijayPrakash','singer',14,'A.R Rehman'),(15,'ShreyaGoshal','singer',15,'A.R Rehman'),(16,'ShreyaGoshal','singer',16,'Amith Thrivedhi');
/*!40000 ALTER TABLE `artist_master` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-26 20:36:10
